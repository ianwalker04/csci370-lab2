# csci370-lab2
Lab 2 for CSCI370.
